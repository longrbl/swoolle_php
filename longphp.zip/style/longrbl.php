<?php
namespace style;

/**
 * Created by 豆豆.
 * User: longrbl@163.com
 * Date: 2016/9/12
 * Time: 22:48
 */
class longrbl
{
private  static  $cla;
    /**
     * 系统初始化
     */
    static public function run(){
      header("Content-type: text/html; charset=utf-8");
        include_once 'fucn/mon.php';//加载公共类
        \style\lib\request::run();
    }
/**
     * @param $class
     * @return 自动加载类
 */
    static public function louad($class){
        $path =APP.'/'.$class.'.php';
       if(self::$cla[$class]){
           return self::$class[$class];
           }else{
           $class=str_replace('\\','/',$class);
//           if(is_file($path)){可以开启检测是否是文件在去加载性能考虑没有加载可以提高5毫秒
           include_once $path;
//           }
           self::$cla[$class]=$class;
       }
    }



}