<?php
/**
 * Created by 豆豆.
 * User: longrbl@163.com
 * Date: 2016/9/13
 * Time: 1:13
 * 模板
 */

namespace style\lib;
use style\lib\request;

class ctlr
{
    /**
     * @param $path 模板路径
     * @param $data 传递到模板的数据
     */
    static function view($path,$data=array()){
            if(is_file(APP.'/app/view/'.$path)){
                extract($data);
                include_once APP.'/app/view/'.$path;
            }else{
                die('模板错误');
            }
    }



}