<?php
namespace app\ctlr;

use app\moder\news;
use style\lib\ctlr;//引入控制器命名空间
use style\lib\page;
use style\lib\request;

//数据库操作语法就在http://medoo.lvtao.net/


class index
{

    public function __construct()
    {
        //可以再这里检查用户是否登陆
        //和一些初始化设置
    }

    static public function indexCtlr(){

           $showrow= 20; //一页显示的行数
           $curpage =request::url(2)?request::url(2):'1'; //当前的页,还应该处理非数字的情况
           $total= news::conmt_s('dou_admin_log');//统计数量
           $url = "/index/index";//连接url
           $piany = ($curpage - 1) * $showrow;
           $sql = news::getall($piany,$showrow);//从数据获取数据并且分页排列
           $page = new page($total, $showrow, $curpage, $url,2);
           $pages = $page->myde_write();
           return ctlr::view('index.html',array('pages'=>$pages,'list'=>$sql,'title'=>'前台测试'));


    }
}